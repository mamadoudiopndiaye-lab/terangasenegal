# Teranga Sénégal

Site vitrine touristique en une page, présentant le Sénégal à travers le concept de « Teranga » (hospitalité sénégalaise).

## Contenu
- `index.html` — page unique (HTML + CSS + JS inline, aucune dépendance à installer)

## Aperçu local
Ouvrez simplement `index.html` dans un navigateur, ou lancez un petit serveur local :

```bash
npx serve .
```

## Déployer sur GitHub

```bash
git init
git add .
git commit -m "Premier commit — site Teranga Sénégal"
git branch -M main
git remote add origin https://github.com/TON-NOM-UTILISATEUR/teranga-senegal.git
git push -u origin main
```

## Déployer sur Netlify
1. Sur [app.netlify.com](https://app.netlify.com), cliquez sur **Add new site → Import an existing project**.
2. Choisissez GitHub et sélectionnez le dépôt `teranga-senegal`.
3. Aucune commande de build n'est nécessaire (site statique) : laissez les champs "Build command" et "Publish directory" vides, ou mettez `.` comme dossier de publication.
4. Cliquez sur **Deploy site**.

## Personnalisation
- Couleurs et polices : variables CSS en haut de `index.html` (`:root { ... }`).
- Destinations : section `<div class="dest-grid">`, une carte `<article class="dest-card">` par lieu.
- Contact : lien `mailto:` dans le footer, à remplacer par votre propre adresse ou un formulaire.
